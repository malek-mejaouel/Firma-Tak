<?php
require_once(__DIR__ . '/../config.php');
include_once(__DIR__ . '/../modele/plants.php'); // Include the Plant class

class PlantC {

    // Method to list all plants
    public function listPlants() {
        $sql = "SELECT * FROM plants"; // SQL query to select all plants
        $db = config::getConnexion(); // Get the database connection
        $stmt = $db->prepare($sql); // Prepare the SQL statement
        $stmt->execute(); // Execute the query

        // Fetch all results as an associative array
        $plants = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $plants; // Return the array of plants
    }

    // Method to delete a plant by ID
    public function deletePlant($ido) {
        $sql = "DELETE FROM plants WHERE ido = :ido"; // SQL query to delete a plant
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':ido', $ido); // Bind the plant ID

        try {
            $req->execute(); // Execute the delete query
            echo "Plant deleted successfully.";
        } catch (PDOException $e) {
            die('Error: ' . $e->getMessage()); // Handle errors
        }
    }

    // Method to add a new plant
    public function addPlant($plant) {
        // Prepare the SQL query to insert a new plant
        $sql = "INSERT INTO plants (namep, descriptionp, statep) VALUES (:namep, :descriptionp, :statep)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'namep' => $plant->getNamep(), // Use getter methods for properties
                'descriptionp' => $plant->getDescriptionp(),
                'statep' => $plant->getStatep()
            ]);

            echo "Plant added successfully.";
            header('Location: ../../view/php/plantsindex.php'); // Redirect after successful insertion
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage(); // Handle errors
        }
    }

    // Method to show details of a single plant by ID
    public function showPlant($ido) {
        $sql = "SELECT * FROM plants WHERE ido = :ido"; // SQL query to fetch a plant by its ID
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->bindValue(':ido', $ido); // Bind the plant ID
            $query->execute();
            $plant = $query->fetch(); // Fetch the plant details

            return $plant; // Return the plant data
        } catch (PDOException $e) {
            die('Error: ' . $e->getMessage()); // Handle errors
        }
    }

    // Method to update plant details
    public function updatePlant($plant, $ido) {
        try {
            $db = config::getConnexion();
            // SQL query to update plant details
            $query = $db->prepare(
                'UPDATE plants SET 
                    namep = :namep,
                    descriptionp = :descriptionp,
                    statep = :statep
                WHERE ido = :idplant'
            );

            // Execute the update query with plant values
            $query->execute([
                'idplant' => $ido,
                'namep' => $plant->getNamep(),
                'descriptionp' => $plant->getDescriptionp(),
                'statep' => $plant->getStatep()
            ]);

            echo $query->rowCount() . " record(s) UPDATED successfully <br>";
        } catch (PDOException $e) {
            echo 'Error updating plant: ' . $e->getMessage(); // Handle errors
        }
    }
}
?>
