<?php
// Activer l'affichage des erreurs pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inclure le fichier de configuration pour établir la connexion à la base de données
require_once(__DIR__ . '/../config.php');  // Assurez-vous que le chemin est correct

// Obtenir la connexion à la base de données via la méthode statique de la classe config
$conn = config::getConnexion();

// Vérifier si la connexion à la base de données est établie
if (!$conn) {
    // Assurez-vous que la connexion échoue proprement en renvoyant une réponse JSON
    header('Content-Type: application/json');
    echo json_encode(["error" => "Database connection failed."]);
    exit;  // Exit to prevent further script execution
}

// Vérifier si le paramètre 'state' est fourni dans l'URL
if (isset($_GET['state'])) {
    $state = $_GET['state'];  // Récupérer l'état via l'URL

    // Préparer la requête SQL pour récupérer les animaux en fonction de l'état
    $stmt = $conn->prepare("SELECT name, description FROM animals WHERE state = :state");

    if ($stmt === false) {
        header('Content-Type: application/json');
        echo json_encode(["error" => "Failed to prepare the SQL statement."]);
        exit;
    }

    // Lier le paramètre 'state' à la requête
    $stmt->bindParam(':state', $state, PDO::PARAM_STR);

    // Exécuter la requête
    $stmt->execute();

    // Vérifier si des résultats ont été retournés
    $animals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Assurez-vous de renvoyer le type de contenu approprié
    header('Content-Type: application/json');
    
    if ($animals) {
        // Retourner les résultats sous forme de JSON
        echo json_encode($animals);
    } else {
        // Si aucun animal n'est trouvé, retourner un tableau vide
        echo json_encode([]);
    }
} else {
    // Retourner un tableau vide si aucun paramètre 'state' n'est fourni
    header('Content-Type: application/json');
    echo json_encode([]);
}
?>
