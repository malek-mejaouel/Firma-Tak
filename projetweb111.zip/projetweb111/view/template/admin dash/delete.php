<?php
require_once(__DIR__ . '/../../../controller/animalsC.php'); // Correct relative path to animalsC.php
$clientC = new AnimalC(); // Correct case for the class name
$clientC->deleteAnimal($_GET["id"]);
header('Location: ../../../../dashboard.html');
exit();
?>
