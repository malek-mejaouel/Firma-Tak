<?php
require_once('/Applications/MAMP/htdocs/projetweb111/controller/animalsC.php');
// Output the full path to see if it's correct
exit();
 // Correct relative path to animalsC.php
$clientC = new AnimalC(); // Correct case for the class name
$clientC->deleteAnimal($_GET["id"]);
header('Location: animalsindex.php');
exit();
?>
