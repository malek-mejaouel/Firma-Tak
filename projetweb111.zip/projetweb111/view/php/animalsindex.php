<?php
require_once(__DIR__ . '/../../config.php'); // Correct path to go up two levels
require_once(__DIR__ . '/../../modele/animals.php'); // Adjusted path to go up two levels
require_once(__DIR__ . '/../../controller/animalsC.php'); // Adjusted path to go up two levels
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
try {
    $db = config::getConnexion();
} catch (Exception $e) {
    die("Connection failed: " . $e->getMessage());
}

// Create an instance of AnimalC
$animalC = new AnimalC();

// Fetch the list of animals
$animals = $animalC->listAnimals();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Animal List</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
        }

        a {
            text-decoration: none;
        }

        li {
            list-style: none;
        }

        h1,
        h2 {
            color: #444;
        }

        h3 {
            color: #999;
        }

        .btn {
            background: #6b7908;
            color: white;
            padding: 5px 10px;
            text-align: center;
            border-radius: 5px;
            display: inline-block;
            margin: 2px;
        }

        .btn:hover {
            color: #6b7908;
            background: white;
            padding: 3px 8px;
            border: 2px solid #6b7908;
        }

        .title {
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 15px 10px;
            border-bottom: 2px solid #999;
        }

        table {
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0; /* Remove any space between table cells */
}

th, td {
    border: 3px solid #ddd;
    padding: 2px 4px; /* Reduced padding to make cells tighter */
    text-align: left;
    font-size: 15px; /* Slightly smaller font for compactness */
}

th {
    background-color: #f2f2f2;
}


        /* Side menu styles */
        .side-menu {
            position: fixed;
            background: #b0b68a;
            width: 20vw;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            padding-left: 10px;
        }

        .side-menu .brand-name {
            height: 10vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .side-menu li {
            font-size: 20px;
            padding: 10px 30px;
            color: white;
            display: flex;
            align-items: center;
        }

        .side-menu li:hover {
            background: rgb(0, 0, 0);
            color: #6b7908;
        }

        /* Main content container */
        .container {
            position: absolute;
            left: 20vw;
            width: 80vw;
            height: 100vh;
            background: #f1f1f1;
        }

        .container .header {
            position: fixed;
            top: 0;
            left: 8vw;
            width: 92vw;
            height: 10vh;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .container .content {
            position: relative;
            margin-top: 10vh;
            min-height: 90vh;
            background: #f1f1f1;
        }

        .container .content .cards {
            padding: 20px 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .container .content .content-2 .recent-payments {
            min-height: 50vh;
            flex: 5;
            background: white;
            margin: 0 25px 25px 25px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            display: flex;
            flex-direction: column;
        }

        /* Button for Add New Animal - Smaller Size */
        .add-link a {
            background: #6b7908;
            color: white;
            padding: 5px 10px; /* Reduced padding for a smaller button */
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px; /* Slightly smaller font size */
            margin-bottom: 10px;
        }

        .add-link a:hover {
            color: #6b7908;
            background: white;
            border: 2px solid #6b7908;
        }

        /* Responsive styles */
        @media screen and (max-width: 1050px) {
            .side-menu li {
                font-size: 18px;
            }
        }

        @media screen and (max-width: 940px) {
            .side-menu li span {
                display: none;
            }
            .side-menu {
                align-items: center;
            }
            .side-menu li img {
                width: 40px;
                height: 40px;
            }
        }

    </style>
</head>
<body>
    <!-- Side menu -->
    <div class="side-menu">
        <div class="brand-name">
            <img src="images/logos.png" alt="">&nbsp;<h2>FIRMA-TAK</h2>
        </div>
        <ul>
            <a href="#"><li><img src="images/dashboard (2).png" alt="">&nbsp; <span>Dashboard</span> </li></a>
            <a href="javascript:void(0);" id="loadOffers">
                <li><img src="images/reading-book (1).png" alt="">&nbsp;<span>idk</span></li>
            </a>
            <!-- Here is the link to the "animalsindex" page without spaces -->
            <a href="http://localhost:8888/projetweb111/view/php/animalsindex.php"><li><img src="images/converted_image_2.png" alt="">&nbsp;<span>AnimalsIndex</span></li></a>
            <a href="http://localhost:8888/projetweb111/view/php/plantsindex.php"><li><img src="images/white_image_revised.png">&nbsp;<span>plants</span></li></a>
            <a href="#"><li><img src="images/payment.png" alt="">&nbsp;<span>Stock</span> </li></a>
            <a href="#"><li><img src="images/help-web-button.png" alt="">&nbsp; <span>Help</span></li></a>
            <a href="#"><li><img src="images/settings.png" alt="">&nbsp;<span>Settings</span> </li></a>
        </ul>
    </div>

    <!-- Main content -->
    <div class="container">
        <h1>List of Animals</h1>

        <!-- Add link to add a new animal -->
        <p class="add-link">
            <a href="add.php">Add New Animal</a>
        </p>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>State</th> <!-- New column for State -->
                <th>Actions</th>
            </tr>
            <?php
            // Check if there are any animals to display
            if ($animals && count($animals) > 0) {
                // Loop through the results and display each animal
                foreach ($animals as $animal) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($animal['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($animal['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($animal['description']) . "</td>";
                    echo "<td>" . htmlspecialchars($animal['state']) . "</td>"; // Display the state
                    echo "<td>
                            <a href='edit.php?id=" . htmlspecialchars($animal['id']) . "' class='btn'>Edit</a> | 
                            <a href='delete.php?id=" . htmlspecialchars($animal['id']) . "' class='btn'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No animals found.</td></tr>"; // Adjusted colspan to 5
            }
            ?>
        </table>
    </div>
</body>
</html>
